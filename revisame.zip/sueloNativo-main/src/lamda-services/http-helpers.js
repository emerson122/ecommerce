// import { of } from 'fp-ts/lib/Task';

// export const replyError = (res) => (error) => of(res.status(500).send(error));
// export const replyOk = (res) => (token) => of(res.json(token));
