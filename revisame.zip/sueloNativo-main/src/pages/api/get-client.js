// import { configure, preferences } from 'mercadopago';

// function configureMercadoPagoSDK() {
//   configure({
//     // sandbox: process.env.useMercadoPagoSandbox === 'true',
//     access_token: 'TEST-6400226030213189-102918-bb0d371b43a6f593addbbce7710a2469-630074681'
//   });
// }

// export default async (req, res) => {
//   configureMercadoPagoSDK()
//   return preferences.create(preference)
//   .then((data)=> res.json(data))
//   .catch((err)=> res.json(err))
// };