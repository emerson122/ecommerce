module.exports = {
  reactStrictMode: true,
  images: {
    domains: [
      'assets.example.com',
      'i2.wp.com',
      'i0.wp.com',
      'cdn.sanity.io',
      'www.mercadopago.com',
      'stallionorganicos.com'
    ],
  },
}